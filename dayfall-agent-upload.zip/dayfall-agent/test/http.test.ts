import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import * as api from '../src/service.js';
const secret='test-only-secret-not-for-deployment';
export const sign=(b:string)=>createHmac('sha256',secret).update(b).digest('hex');
export async function start(t:any,options:any={}){assert.equal(typeof api.createAgent,'function');const replayDir=await mkdtemp(join(process.env.TMPDIR??tmpdir(),'dayfall-http-'));const server=api.createAgent({secret,replayDir,...options});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));t.after(()=>new Promise<void>(r=>server.close(()=>r())));return `http://127.0.0.1:${(server.address() as any).port}/agent`;}
export async function post(url:string,value:any,signature?:string){const raw=typeof value==='string'?value:JSON.stringify(value);const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json','x-agent-games-signature':signature??sign(raw)},body:raw});const body=await response.text();assert.equal(response.headers.get('x-agent-games-signature'),sign(body));return {status:response.status,body:JSON.parse(body)};}
test('authentication rejects invalid HMAC before attempting JSON parsing',async t=>{const url=await start(t);const r=await post(url,'not json','00'.repeat(32));assert.equal(r.status,401);assert.equal(r.body.reason_code,'INVALID_SIGNATURE');const spaced=' { "type": "agent-games.preflight.v1", "issued_at":"'+new Date().toISOString()+'", "nonce":"raw", "agent_id":"agt_test" } ';assert.equal((await post(url,spaced,sign(JSON.stringify(JSON.parse(spaced))))).status,401);});
test('authentication accepts uppercase hex MAC bytes',async t=>{
 const url=await start(t),raw=JSON.stringify({type:'agent-games.preflight.v1',agent_id:'hex',nonce:'uppercase',issued_at:new Date().toISOString()});
 const r=await post(url,raw,sign(raw).toUpperCase());assert.equal(r.status,200);assert.deepEqual(r.body,{ok:true,protocolVersion:'v1'});
});
test('authentication accepts sha256= hex without changing raw body bytes',async t=>{
 const url=await start(t);
 for(const upper of [false,true]){const raw=' '+JSON.stringify({type:'agent-games.preflight.v1',agent_id:'prefix',nonce:String(upper),issued_at:new Date().toISOString()})+'\n';const hex=sign(raw);assert.equal((await post(url,raw,'sha256='+(upper?hex.toUpperCase():hex))).status,200);}
});
test('authentication accepts canonical 32-byte base64 with optional sha256= prefix',async t=>{
 const url=await start(t);
 for(const prefix of ['', 'sha256=']){const raw=JSON.stringify({type:'agent-games.preflight.v1',agent_id:'base64',nonce:prefix||'bare',issued_at:new Date().toISOString()});assert.equal((await post(url,raw,prefix+Buffer.from(sign(raw),'hex').toString('base64'))).status,200);}
});
test('authentication failure logs only the format enum and never request data',async t=>{
 const url=await start(t),logs:unknown[][]=[];t.mock.method(console,'warn',(...args:unknown[])=>{logs.push(args);});
 const cases:[string|undefined,string][]=[[undefined,'missing'],['00'.repeat(32),'hex'],['sha256='+'00'.repeat(32),'prefixed-hex'],[Buffer.alloc(32).toString('base64'),'base64'],['sha256='+Buffer.alloc(32).toString('base64'),'base64'],['private-attacker-value','other']];
 for(const [signature,format] of cases){const headers:Record<string,string>={};if(signature!==undefined)headers['x-agent-games-signature']=signature;const response=await fetch(url,{method:'POST',headers,body:'private-body-value'});assert.equal(response.status,401);await response.text();assert.deepEqual(logs.at(-1),[format]);}
 assert.deepEqual(logs,cases.map(([,format])=>[format]));
 const raw=JSON.stringify({type:'agent-games.preflight.v1',agent_id:'quiet',nonce:'success',issued_at:new Date().toISOString()});assert.equal((await post(url,raw)).status,200);assert.equal(logs.length,cases.length);
});
test('authentication rejects malformed encodings, tampered raw bytes and changed secrets',async t=>{
 const url=await start(t),raw=' {"private":"body"} ',hex=sign(raw),b64=Buffer.from(hex,'hex').toString('base64');
 const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',last=alphabet.indexOf(b64[42]),alias=b64.slice(0,42)+alphabet[last+1]+'=';
 assert.deepEqual(Buffer.from(alias,'base64'),Buffer.from(b64,'base64'));
 const malformed=['',hex.slice(1),hex+'0',hex.slice(0,63)+'g','sha256=sha256='+hex,'SHA256='+hex,'sha256= '+hex,hex+', '+hex,b64.slice(0,-1),b64+'=',alias,b64.slice(0,10)+' '+b64.slice(10),Buffer.alloc(31).toString('base64'),Buffer.alloc(33).toString('base64'),Buffer.alloc(32,255).toString('base64url')];
 for(const signature of malformed){const r=await post(url,raw,signature);assert.equal(r.status,401);assert.equal(r.body.reason_code,'INVALID_SIGNATURE');}
 for(const signature of [hex,hex.toUpperCase(),'sha256='+hex,b64,'sha256='+b64])assert.equal((await post(url,raw+' ',signature)).status,401);
 for(const changedSecret of [secret+' ',Buffer.from(secret).toString('base64')])assert.equal((await post(url,raw,createHmac('sha256',changedSecret).update(raw).digest('hex'))).status,401);
});
test('schema rejection reports bounded structural facts without request values',async t=>{
 const url=await start(t),logs:unknown[][]=[];t.mock.method(console,'warn',(...args:unknown[])=>{logs.push(args);});
 const value:any=task('private-task-marker');value.mode='practice';delete value.input.proof_tx;value.input.recipient='0xDe42...9f01';value.input.amount=500;value.input.minimum='18446744073709551616';value.input.current_block=-1;value.input['private-field-marker']='private-value-marker';
 const r=await post(url,value);assert.equal(r.status,400);assert.equal(r.body.reason_code,'INVALID_SCHEMA');assert.equal(logs.length,1);assert.equal(logs[0][0],'SCHEMA_REJECT');
 const raw=logs[0][1] as string;assert.ok(raw.length<=4096);const d=JSON.parse(raw);
 assert.deepEqual(d['input.proof_tx'],{type:'missing',hex64:false});assert.deepEqual(d['input.recipient'],{type:'string',length:13,hex40:false});
 assert.deepEqual(d['input.amount'],{type:'number',decimal:false,uint64:false});assert.equal(d['input.minimum'].decimal,true);assert.equal(d['input.minimum'].uint64,false);assert.equal(d['input.current_block'].safeInteger,true);assert.equal(d['input.current_block'].nonnegative,false);
 for(const forbidden of [secret,sign(JSON.stringify(value)),value.task_id,value.input.recipient,'private-field-marker','private-value-marker','18446744073709551616'])assert.equal(raw.includes(forbidden),false);
 logs.length=0;assert.equal((await post(url,task('quiet-valid'))).status,200);assert.equal(logs.length,0);
});
test('schema diagnostics cover envelope, type, mode, task id and every input validator',async t=>{
 const url=await start(t),logs:unknown[][]=[];t.mock.method(console,'warn',(...args:unknown[])=>{logs.push(args);});
 const cases:[any,string,string,unknown][]=[
  [null,'envelope','type','null'],[[],'envelope','type','array'],[7,'envelope','type','number'],
  [{...task(),type:'private-unknown-type'},'type','allowed',false],
  [{...task(),mode:'private-unknown-mode'},'mode','allowed',false],
  [{...task(),task_id:''},'task_id','bounded',false],[{...task(),task_id:'x'.repeat(257)},'task_id','bounded',false],
  [{type:'agent-games.preflight.v1',agent_id:{},nonce:'x'},'agent_id','bounded',false],
  [{type:'agent-games.preflight.v1',agent_id:'x',nonce:null},'nonce','bounded',false],
  [{...task(),input:null},'input','type','null']
 ];
 for(const field of ['registered_vk','proof_vk','proof_tx'])for(const bad of [undefined,7,'0xa8...2c','0x'+'gg'.repeat(32)])cases.push([{...task(),input:{...task().input,[field]:bad}},'input.'+field,'hex64',false]);
 for(const field of ['recipient','condition_recipient'])cases.push([{...task(),input:{...task().input,[field]:'0xDe42...9f01'}},'input.'+field,'hex40',false]);
 for(const field of ['minimum','public_balance','amount','max_transfer'])for(const bad of [7,'01','-1','9'.repeat(21)])cases.push([{...task(),input:{...task().input,[field]:bad}},'input.'+field,'decimal',false]);
 for(const field of ['expiry_block','current_block'])cases.push([{...task(),input:{...task().input,[field]:1.5}},'input.'+field,'safeInteger',false]);
 for(const [value,field,predicate,expected] of cases){logs.length=0;const r=await post(url,value);assert.equal(r.status,400);assert.equal(r.body.reason_code,'INVALID_SCHEMA');assert.equal(logs.length,1);assert.equal(logs[0][0],'SCHEMA_REJECT');const raw=logs[0][1] as string;assert.ok(raw.length<=4096);assert.equal(JSON.parse(raw)[field][predicate],expected);assert.equal(raw.includes('private-unknown'),false);}
 // A huge nested unknown field cannot expand output; each request emits one fixed-shape record.
 logs.length=0;const huge={...task(),mode:{nested:'private-marker'.repeat(3000)},task_id:[],input:{proof_tx:{nested:'private-marker'}}};assert.equal((await post(url,huge)).status,400);assert.ok((logs[0][1] as string).length<=4096);assert.equal((logs[0][1] as string).includes('private-marker'),false);
 // JSON/auth/transport failures and accepted practice tasks never emit schema diagnostics.
 logs.length=0;assert.equal((await post(url,'broken')).body.reason_code,'INVALID_JSON');assert.equal(logs.length,0);
 assert.equal((await post(url,'broken','00'.repeat(32))).status,401);assert.deepEqual(logs,[['hex']]);logs.length=0;
 const valid=task('quiet-practice');valid.mode='practice';assert.equal((await post(url,valid)).status,200);assert.equal(logs.length,0);
});
test('timestamps and task deadlines fail closed before work',async t=>{const url=await start(t);for(const value of [{type:'agent-games.preflight.v1',issued_at:'bad',nonce:'x',agent_id:'x'},{type:'agent-games.preflight.v1',issued_at:new Date(Date.now()-120000).toISOString(),nonce:'x',agent_id:'x'},{type:'agent-games.proof-gatekeeper.v1',issued_at:new Date().toISOString(),deadline_at:new Date(Date.now()-1000).toISOString()}]){const r=await post(url,value);assert.equal(r.status,400);assert.equal(r.body.decision,'REJECT');}assert.equal((await post(url,'broken')).status,400);});
import {mkdtemp} from 'node:fs/promises';import {tmpdir} from 'node:os';import {join} from 'node:path';
export const task=(id='gk_test',proof='ab')=>({type:'agent-games.proof-gatekeeper.v1',task_id:id,mode:'competition',issued_at:new Date().toISOString(),deadline_at:new Date(Date.now()+50000).toISOString(),input:{registered_vk:'0x6b79c6012a6d8651f3e13bc4d2a20370280ab49700c90c5316d4168bfbad77b0',proof_vk:'0x6b79c6012a6d8651f3e13bc4d2a20370280ab49700c90c5316d4168bfbad77b0',minimum:'1000',public_balance:'1460',expiry_block:8430000,current_block:8420000,recipient:'0x'+'11'.repeat(20),condition_recipient:'0x'+'11'.repeat(20),amount:'500',max_transfer:'1000',proof_tx:'0x'+proof.repeat(32)}});
test('real task fails closed on unspecified finality and never echoes an unverified proof_tx',async t=>{const replayDir=await mkdtemp(join(tmpdir(),'dayfall-'));const url=await start(t,{replayDir});const r=await post(url,task());assert.equal(r.body.decision,'REJECT');assert.equal(r.body.reason_code,'FINALIZATION_UNSPECIFIED');assert.equal(r.body.proof_tx,undefined);});
test('matching tasks return cached responses, proof reuse and task conflicts stay distinct',async t=>{const replayDir=await mkdtemp(join(process.env.TMPDIR??tmpdir(),'dayfall-'));const url=await start(t,{replayDir});const value=task('gk_race');const requests=await Promise.all([post(url,value),post(url,value)]);assert.deepEqual(requests[0].body,requests[1].body);const url2=await start(t,{replayDir});assert.deepEqual((await post(url2,value)).body,requests[0].body);assert.equal((await post(url2,task('gk_other'))).body.reason_code,'PROOF_REUSED');assert.equal((await post(url2,{...value,input:{...value.input,proof_tx:'0x'+'cd'.repeat(32)}})).body.reason_code,'TASK_ID_CONFLICT');});
test('nested array object keys share the exact cached HTTP response while array order conflicts',async t=>{
 const url=await start(t);
 const send=async(value:any)=>{const raw=JSON.stringify(value);const response=await fetch(url,{method:'POST',headers:{'content-type':'application/json','x-agent-games-signature':sign(raw)},body:raw});return {status:response.status,raw:await response.text(),signature:response.headers.get('x-agent-games-signature')};};
 const value={...task('gk_array_keys'),metadata:[{a:1,b:2}]};
 const first=await send(value);assert.equal(first.status,200);assert.equal(JSON.parse(first.raw).reason_code,'FINALIZATION_UNSPECIFIED');assert.equal(first.signature,sign(first.raw));
 assert.deepEqual(await send({...value,metadata:[{b:2,a:1}]}),first);
 const ordered={...task('gk_array_order','cd'),metadata:[{a:1,b:2},{a:3,b:4}]};
 const original=await send(ordered);assert.equal(JSON.parse(original.raw).reason_code,'FINALIZATION_UNSPECIFIED');
 const reversed=await send({...ordered,metadata:[...ordered.metadata].reverse()});assert.equal(reversed.status,200);assert.equal(JSON.parse(reversed.raw).reason_code,'TASK_ID_CONFLICT');assert.equal(reversed.signature,sign(reversed.raw));
});
test('preflight identities require bounded strings and tuple keys avoid delimiter collisions',async t=>{const url=await start(t);for(const [agent_id,nonce] of [[{},'n'],['a',{}],['','n'],['a','n'.repeat(257)]])assert.equal((await post(url,{type:'agent-games.preflight.v1',issued_at:new Date().toISOString(),agent_id,nonce})).status,400);for(const [agent_id,nonce] of [['a:b','c'],['a','b:c']])assert.deepEqual((await post(url,{type:'agent-games.preflight.v1',issued_at:new Date().toISOString(),agent_id,nonce})).body,{ok:true,protocolVersion:'v1'});});
test('opt-in signed-envelope policy attaches real proofs on approvals and all provable traps',async t=>{const url=await start(t,{encoding:'sha256-field-v1',approvalMode:'signed-envelope'});const {verify}=await import('../src/proof.js');for(const [j,patch,reason] of [[0,{},'VALID_CONDITION'],[1,{proof_vk:'0x'+'22'.repeat(32)},'VK_SUBSTITUTION'],[2,{public_balance:'999'},'THRESHOLD_MISMATCH'],[3,{current_block:8430000},'EXPIRED_CONDITION'],[4,{recipient:'0x'+'33'.repeat(20)},'RECIPIENT_MISMATCH'],[5,{amount:'1001'},'AMOUNT_OVERFLOW']] as const){const value=task('gk_real_'+j,(40+j).toString(16));value.input={...value.input,...patch};const r=await post(url,value);assert.equal(r.body.reason_code,reason);assert.equal(r.body.decision,j===0?'APPROVE':'REJECT');assert.equal(await verify(r.body),true);assert.equal(r.body.proof_tx,undefined);const retry=await post(url,value);assert.deepEqual(retry.body,r.body);}});
test('34-character Practice reference receives a real signed proof and durable case-insensitive reuse protection',async t=>{
 const replayDir=await mkdtemp(join(process.env.TMPDIR??tmpdir(),'dayfall-short-ref-'));
 const options={replayDir,encoding:'sha256-field-v1',approvalMode:'signed-envelope'};
 const url=await start(t,options),value=task('practice_9220e265-75dd-4e1f-a348-7aa90db633f9');value.mode='practice';
 const reference='0xAbCd0123456789eFAbCd0123456789eF';value.input.proof_tx=reference;
 assert.equal(reference.length,34);assert.equal('agent_id' in value,false);assert.equal('nonce' in value,false);
 const original=JSON.stringify(value),r=await post(url,value);assert.equal(r.status,200);assert.equal(r.body.decision,'APPROVE');assert.equal(r.body.reason_code,'VALID_CONDITION');assert.equal(r.body.proof_tx,undefined);
 const {verify}=await import('../src/proof.js');assert.equal(await verify(r.body),true);assert.equal(JSON.stringify(value),original);
 const url2=await start(t,options);assert.deepEqual(await post(url2,value),r);
 const reused={...value,task_id:'practice_other',input:{...value.input,proof_tx:reference.toLowerCase()}};
 const replay=await post(url2,reused);assert.equal(replay.status,200);assert.equal(replay.body.reason_code,'PROOF_REUSED');assert.equal(replay.body.proof,undefined);
 const changed={...value,input:{...value.input,proof_tx:reference.toLowerCase()}};assert.equal((await post(url2,changed)).body.reason_code,'TASK_ID_CONFLICT');
 const conservative=await start(t);assert.equal((await post(conservative,value)).body.reason_code,'FINALIZATION_UNSPECIFIED');
});
 test('proof references reject malformed tokens while VKs still require exactly 32 bytes',async t=>{
 const url=await start(t);t.mock.method(console,'warn',()=>{});
 const bad=[undefined,null,7,{},'','0x','0x'+'ab'.repeat(15),'0x'+'ab'.repeat(17),'0x'+'a'.repeat(31),'0x'+'a'.repeat(33),'0x'+'a'.repeat(63),'0x'+'a'.repeat(65),'0x'+'ab'.repeat(33),'0x'+'gg'.repeat(16),'0x'+'gg'.repeat(32),'0X'+'ab'.repeat(16),' '+'0x'+'ab'.repeat(16),'0x'+'ab'.repeat(16)+' ','0x'+'ab'.repeat(15)+'\n','0x'+'ab'.repeat(16)+'\n','0x'+'ab'.repeat(32)+'\n'];
 for(const proof_tx of bad){const value={...task(),input:{...task().input,proof_tx}};const r=await post(url,value);assert.equal(r.status,400,JSON.stringify(proof_tx));assert.equal(r.body.reason_code,'INVALID_SCHEMA');}
 for(const field of ['registered_vk','proof_vk']){const value=task();value.input[field as 'registered_vk'|'proof_vk']='0x'+'ab'.repeat(16);assert.equal((await post(url,value)).status,400);}
});
 test('transport bounds and schema reject malformed, oversized, unknown or misrouted requests',async t=>{const url=await start(t);assert.equal((await post(url.replace('/agent','/wrong'),{})).status,404);assert.equal((await post(url,'x'.repeat(70000))).status,413);for(const value of [null,{type:'unknown',issued_at:new Date().toISOString(),deadline_at:new Date(Date.now()+30000).toISOString()},{type:'agent-games.preflight.v1',issued_at:new Date().toISOString()}, {...task(),input:{proof_tx:7}}, {...task(),task_id:''}])assert.equal((await post(url,value)).status,400);assert.throws(()=>api.createAgent({secret:''}),/SECRET/);});
test('preflight nonce replay fails closed across instances',async t=>{const replayDir=await mkdtemp(join(process.env.TMPDIR??tmpdir(),'dayfall-preflight-'));const url=await start(t,{replayDir}),url2=await start(t,{replayDir});const p={type:'agent-games.preflight.v1',agent_id:'agt_same',nonce:'same',issued_at:new Date().toISOString()};assert.equal((await post(url,p)).status,200);assert.equal((await post(url2,p)).body.reason_code,'REPLAY');});
test('signed preflight runs over real HTTP with exact raw response signature',async t=>{const url=await start(t);const r=await post(url,{type:'agent-games.preflight.v1',agent_id:'agt_test',issued_at:new Date().toISOString(),nonce:'abc123'});assert.equal(r.status,200);assert.deepEqual(r.body,{ok:true,protocolVersion:'v1'});});

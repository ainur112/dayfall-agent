import {test} from 'node:test';
import assert from 'node:assert/strict';
import * as api from '../src/proof.js';
export const witness={taskId:'1',registeredVkHash:'123',proofVkHash:'123',minimum:'1000',publicBalance:'1460',expiryBlock:'8430000',currentBlock:'8420000',recipient:'42',conditionRecipient:'42',amount:'500',maxTransfer:'1000',decision:'1',salt:'99'};
test('official circuit proves REJECT for an actual failed balance condition',async()=>{const e=await api.prove({...witness,publicBalance:'999',decision:'0'});assert.equal(await api.verify(e),true);console.log('observed rejection public signals',e.public_signals);});
test('official artifacts generate a real locally verifiable proof',async()=>{
 assert.equal(typeof api.prove,'function');
 const result=await api.prove(witness);
 assert.equal(await api.verify(result),true);
 assert.equal(result.public_signals.length,13);
 const tampered={...result,public_signals:[...result.public_signals]}; tampered.public_signals[0]='999';
 assert.equal(await api.verify(tampered),false);
});

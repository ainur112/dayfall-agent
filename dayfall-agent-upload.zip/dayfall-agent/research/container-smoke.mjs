import {spawn,execFileSync} from 'node:child_process';
import {createHmac,randomBytes} from 'node:crypto';
const secret=randomBytes(32).toString('hex');
const child=spawn('docker',['run','--rm','--name','dayfall-agent-smoke','-p','127.0.0.1:32187:3000','-e','AGENT_GAMES_HMAC_SECRET','dayfall-agent:local'],{env:{...process.env,AGENT_GAMES_HMAC_SECRET:secret},stdio:['ignore','pipe','pipe']});
let output='';child.stdout.on('data',b=>output+=b);child.stderr.on('data',b=>output+=b);
const sign=raw=>createHmac('sha256',secret).update(raw).digest('hex');
try{
 let response;
 for(let n=0;n<50;n++){
  try{const raw=JSON.stringify({type:'agent-games.preflight.v1',agent_id:'agt_smoke',nonce:'container-smoke',issued_at:new Date().toISOString()});response=await fetch('http://127.0.0.1:32187/agent',{signal:AbortSignal.timeout(1000),method:'POST',headers:{'x-agent-games-signature':sign(raw)},body:raw});break;}catch{await new Promise(r=>setTimeout(r,100));}
 }
 if(!response)throw Error('Container failed startup: '+output);
 const body=await response.text();
 if(response.status!==200||response.headers.get('x-agent-games-signature')!==sign(body)||JSON.parse(body).ok!==true)throw Error('Container signed preflight failed');
 console.log('Container smoke PASS: actual HTTP signed preflight verified; runtime started as configured.');
}finally{const closed=new Promise(r=>child.on('close',r));try{execFileSync('docker',['stop','-t','1','dayfall-agent-smoke'],{stdio:'ignore'});}catch{}await closed;}

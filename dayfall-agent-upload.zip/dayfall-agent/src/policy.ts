export const VK='0x6b79c6012a6d8651f3e13bc4d2a20370280ab49700c90c5316d4168bfbad77b0';
export function check(i:any):string{
 if(!i||['minimum','public_balance','amount','max_transfer'].some(k=>typeof i[k]!=='string'||i[k].length>20||! /^(0|[1-9][0-9]*)$/.test(i[k])||BigInt(i[k])>=2n**64n)||['expiry_block','current_block'].some(k=>!Number.isSafeInteger(i[k])||i[k]<0)||['registered_vk','proof_vk','proof_tx'].some(k=>typeof i[k]!=='string'||!/^0x[0-9a-fA-F]{64}$/.test(i[k]))||['recipient','condition_recipient'].some(k=>typeof i[k]!=='string'||!/^0x[0-9a-fA-F]{40}$/.test(i[k])))return 'INVALID_INPUT';
 if(i.proof_vk.toLowerCase()!==i.registered_vk.toLowerCase())return 'VK_SUBSTITUTION';
 if(BigInt(i.public_balance)<BigInt(i.minimum))return 'THRESHOLD_MISMATCH';
 if(i.current_block>=i.expiry_block)return 'EXPIRED_CONDITION';
 if(i.recipient.toLowerCase()!==i.condition_recipient.toLowerCase())return 'RECIPIENT_MISMATCH';
 if(BigInt(i.amount)>BigInt(i.max_transfer))return 'AMOUNT_OVERFLOW';
 return 'VALID_CONDITION';
}

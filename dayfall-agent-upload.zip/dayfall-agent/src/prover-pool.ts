import {fork,type ChildProcess} from 'node:child_process';import type {Evidence} from './proof.js';import {expectedSignals} from './encoding.js';
export class ProverPool{
 private active=0;
 constructor(private limit=2){if(!Number.isInteger(limit)||limit<1||limit>8)throw Error('INVALID_WORKER_LIMIT');}
 async prove(witness:Record<string,string>,deadline:number):Promise<Evidence>{
  if(Date.now()>=deadline)throw Error('PROOF_DEADLINE');if(this.active>=this.limit)throw Error('PROVER_BUSY');this.active++;
  let worker:ChildProcess|undefined;
  try{return await new Promise<Evidence>((resolve,reject)=>{
   const development=import.meta.url.endsWith('.ts');
   worker=fork(new URL('./proof-worker.js',import.meta.url),[],{execArgv:['--max-old-space-size=256'],stdio:['ignore','ignore','ignore','ipc']});
   worker.send({witness,development});
   const timer=setTimeout(()=>reject(Error('PROOF_DEADLINE')),Math.max(1,deadline-Date.now()));
   worker.once('error',e=>{clearTimeout(timer);reject(e);});worker.once('exit',code=>{clearTimeout(timer);reject(Error('PROOF_WORKER_EXIT_'+code));});
   worker.once('message',(m:any)=>{clearTimeout(timer);if(m.error){reject(Error('PROOF_FAILED'));return;}if(m.public_signals?.length!==13||m.public_signals.slice(1).some((v:string,j:number)=>v!==expectedSignals(witness)[j]))reject(Error('SIGNAL_BINDING_MISMATCH'));else resolve(m);});
  });}finally{if(worker&&!worker.killed&&worker.exitCode===null&&worker.signalCode===null){await new Promise<void>(resolve=>{worker!.once('exit',()=>resolve());worker!.kill();});}this.active--;}
 }
}

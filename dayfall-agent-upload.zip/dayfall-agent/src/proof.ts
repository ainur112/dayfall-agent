import {assertArtifacts} from './artifacts.js';
import {groth16} from 'snarkjs';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
export type Evidence={proof:any;public_signals:string[]};
const root=new URL('../',import.meta.url);
export async function prove(witness:Record<string,string>):Promise<Evidence>{
 await assertArtifacts();
 const {proof,publicSignals}=await groth16.fullProve(witness,fileURLToPath(new URL('gatekeeper.wasm',root)),fileURLToPath(new URL('gatekeeper_final.zkey',root)),undefined,undefined,{singleThread:true});
 const evidence={proof,public_signals:publicSignals};
 if(!await verify(evidence))throw Error('LOCAL_VERIFICATION_FAILED');
 return evidence;
}
export async function verify(e:Evidence):Promise<boolean>{try{return await groth16.verify(JSON.parse(await readFile(new URL('verification_key.json',root),'utf8')),e.public_signals,e.proof);}finally{await (globalThis as any).curve_bn128?.terminate();}}

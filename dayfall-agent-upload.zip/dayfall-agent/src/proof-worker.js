// JS bootstrap permits both tsx development and compiled Node execution.
process.once('message',async(workerData)=>{
try{
 let api;
 if(workerData.development){const {tsImport}=await import('tsx/esm/api');api=await tsImport('./proof.ts',import.meta.url);}
 else api=await import('./proof.js');
 process.send(await api.prove(workerData.witness));
}catch{process.send({error:'PROOF_FAILED'});}
});

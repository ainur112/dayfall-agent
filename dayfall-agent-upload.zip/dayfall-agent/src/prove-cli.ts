import {readFile,writeFile} from 'node:fs/promises';
import {prove} from './proof.js';
const [input,output]=process.argv.slice(2);
if(!input||!output)throw Error('Usage: prove-cli <witness.json> <evidence.json>');
const witness=JSON.parse(await readFile(input,'utf8'));
const evidence=await prove(witness);
await writeFile(output,JSON.stringify(evidence,null,2)+'\n',{mode:0o600});
console.log('Groth16 proof verified locally; no chain finalization claimed.');

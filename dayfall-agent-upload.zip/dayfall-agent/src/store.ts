import {mkdirSync,openSync,writeFileSync,fsyncSync,closeSync,readFileSync,renameSync} from 'node:fs';
import {createHash,randomUUID} from 'node:crypto';import {join} from 'node:path';
const reject=(reason_code:string)=>JSON.stringify({decision:'REJECT',reason_code});
function durable(path:string,value:string){const fd=openSync(path,'wx',0o600);try{writeFileSync(fd,value);fsyncSync(fd);}finally{closeSync(fd);}}
/** Single shared local filesystem; exclusive reservations never expire or get stolen. */
export class TaskStore{
 constructor(private dir:string){}
 private path(key:string){return join(this.dir,createHash('sha256').update(key).digest('hex'));}
 async run(id:string,fingerprint:string,proof:string,deadline:number,work:()=>Promise<string>):Promise<string>{
  try{
   mkdirSync(this.dir,{recursive:true});const path=this.path('task:'+id),result=path+'.response';
   let owner=false;
   try{durable(path,fingerprint);owner=true;}catch(e){if((e as NodeJS.ErrnoException).code!=='EEXIST')throw e;}
   if(!owner){
    if(readFileSync(path,'utf8')!==fingerprint)return reject('TASK_ID_CONFLICT');
    do{try{return readFileSync(result,'utf8');}catch(e){if((e as NodeJS.ErrnoException).code!=='ENOENT')throw e;}if(Date.now()>=deadline)return reject('TASK_IN_PROGRESS');await new Promise(r=>setTimeout(r,20));}while(true);
   }
   let response:string;
   try{durable(this.path('proof:'+proof.toLowerCase()),id);response=await work();}
   catch(e){response=reject((e as NodeJS.ErrnoException).code==='EEXIST'?'PROOF_REUSED':'TASK_FAILED');}
   const temp=result+'.'+randomUUID();durable(temp,response);renameSync(temp,result);return response;
  }catch{return reject('REPLAY_STORE_ERROR');}
 }
}

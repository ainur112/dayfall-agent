import {mkdirSync,openSync,writeSync,fsyncSync,closeSync} from 'node:fs';import {join} from 'node:path';import {createHash,createHmac,timingSafeEqual} from 'node:crypto';
import {check} from './policy.js';import {encode} from './encoding.js';import {TaskStore} from './store.js';import {ProverPool} from './prover-pool.js';import {createServer} from 'node:http';
const boundedString=(v:unknown):v is string=>typeof v==='string'&&v.length>0&&v.length<=256;
const canonical=(v:any):string=>{if(Array.isArray(v))return '['+v.map(canonical).join(',')+']';if(v&&typeof v==='object')return '{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}';return JSON.stringify(v);};
export function createAgent(options:{secret:string;replayDir?:string;encoding?:'disabled'|'sha256-field-v1';approvalMode?:'require-finality'|'signed-envelope';proofWorkers?:number;proofBudgetMs?:number}){
 if(!options.secret)throw Error('AGENT_GAMES_HMAC_SECRET_REQUIRED');
 const dir=options.replayDir??'data/replay',store=new TaskStore(dir),pool=new ProverPool(options.proofWorkers??2);
 const server=createServer((req,res)=>{
 const sendRaw=(status:number,raw:string)=>{if(res.destroyed||res.writableEnded)return;res.writeHead(status,{'content-type':'application/json','x-agent-games-signature':createHmac('sha256',options.secret).update(raw).digest('hex')});res.end(raw);};
 const send=(status:number,value:unknown)=>sendRaw(status,JSON.stringify(value));
 req.on('error',()=>{});res.on('error',()=>{});
 void (async()=>{
 if(req.url!=='/agent'){req.resume();send(404,{decision:'REJECT',reason_code:'NOT_FOUND'});return;}
 if(req.method!=='POST'){req.resume();send(405,{decision:'REJECT',reason_code:'METHOD_NOT_ALLOWED'});return;}
 const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>65536){req.resume();send(413,{decision:'REJECT',reason_code:'BODY_TOO_LARGE'});return;}chunks.push(Buffer.from(chunk));}const body=Buffer.concat(chunks);
 // Decode only strict, canonical representations; HMAC still covers the exact received bytes.
 const header=req.headers['x-agent-games-signature'],prefixed=typeof header==='string'&&header.startsWith('sha256='),signature=prefixed?header.slice(7):header;
 const isHex=typeof signature==='string'&&/^[0-9a-fA-F]{64}$/.test(signature);
 let mac:Buffer|undefined;
 if(isHex)mac=Buffer.from(signature as string,'hex');
 else if(typeof signature==='string'&&/^[A-Za-z0-9+/]{43}=$/.test(signature)){
  const decoded=Buffer.from(signature,'base64');
  if(decoded.length===32&&decoded.toString('base64')===signature)mac=decoded;
 }
 const format:'missing'|'hex'|'prefixed-hex'|'base64'|'other'=header===undefined?'missing':isHex?(prefixed?'prefixed-hex':'hex'):mac?'base64':'other';
 const expected=createHmac('sha256',options.secret).update(body).digest();
 if(!mac||mac.length!==32||!timingSafeEqual(mac,expected)){
  // Deliberately emit only this enum, never attacker-controlled text or request/secret data.
  console.warn(format);send(401,{decision:'REJECT',reason_code:'INVALID_SIGNATURE'});return;
 }
 let task:any;try{task=JSON.parse(body.toString('utf8'));}catch{send(400,{decision:'REJECT',reason_code:'INVALID_JSON'});return;}
 if(!task||typeof task!=='object'||!['agent-games.preflight.v1','agent-games.proof-gatekeeper.v1'].includes(task.type)||(task.type==='agent-games.preflight.v1'&&(!boundedString(task.agent_id)||!boundedString(task.nonce)))||(task.type==='agent-games.proof-gatekeeper.v1'&&(!boundedString(task.task_id)||!['competition','practice'].includes(task.mode)||check(task.input)==='INVALID_INPUT'))){send(400,{decision:'REJECT',reason_code:'INVALID_SCHEMA'});return;}
 const now=Date.now(),issued=typeof task.issued_at==='string'?Date.parse(task.issued_at):NaN,deadline=typeof task.deadline_at==='string'?Date.parse(task.deadline_at):NaN;
 if(task.type==='agent-games.proof-gatekeeper.v1'){
 const fingerprint=createHash('sha256').update(canonical(task)).digest('hex');
 const response=await store.run(task.task_id,fingerprint,task.input.proof_tx,Math.min(Number.isFinite(deadline)?deadline:now,now+50000),async()=>{
 const reject=(reason_code:string)=>JSON.stringify({decision:'REJECT',reason_code});
 if(!Number.isFinite(issued)||issued>now+5000||now-issued>60000||!Number.isFinite(deadline)||deadline<=now||deadline<=issued||deadline-issued>60000)return reject('INVALID_TIMESTAMP');
 const reason=check(task.input),decision=reason==='VALID_CONDITION'?'APPROVE':'REJECT';
 if(decision==='APPROVE'&&options.approvalMode!=='signed-envelope')return reject('FINALIZATION_UNSPECIFIED');
 if(options.encoding!=='sha256-field-v1')return reject('ENCODING_UNCONFIRMED');
 try{const witness=encode(task,decision),evidence=await pool.prove(witness,Math.min(deadline-500,Date.now()+(options.proofBudgetMs??45000)));return JSON.stringify({decision,reason_code:reason,...evidence});}
 catch(e){const message=(e as Error).message;return reject(message==='VK_FIELD_ALIAS'?'VK_SUBSTITUTION':message.startsWith('PROOF_')||message==='PROVER_BUSY'?message:'PROOF_FAILED');}
 });sendRaw(200,response);return;
 }
 if(!Number.isFinite(issued)||issued>now+5000||now-issued>60000){send(400,{decision:'REJECT',reason_code:'INVALID_TIMESTAMP'});return;}
 try{mkdirSync(dir,{recursive:true});const key=JSON.stringify([task.agent_id,task.nonce]);const fd=openSync(join(dir,createHash('sha256').update('preflight:'+key).digest('hex')),'wx',0o600);try{writeSync(fd,'reserved\n');fsyncSync(fd);}finally{closeSync(fd);}}catch(error){send(200,{decision:'REJECT',reason_code:(error as NodeJS.ErrnoException).code==='EEXIST'?'REPLAY':'REPLAY_STORE_ERROR'});return;}
 send(200,{ok:true,protocolVersion:'v1'});
 })().catch(()=>{try{send(400,{decision:'REJECT',reason_code:'REQUEST_FAILED'});}catch{res.destroy();}});
 });
 server.requestTimeout=10000;server.headersTimeout=10000;server.timeout=60000;return server;
}

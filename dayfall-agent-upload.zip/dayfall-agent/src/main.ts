import {createAgent} from './service.js';
const encoding=process.env.PROOF_ENCODING??'disabled';if(!['disabled','sha256-field-v1'].includes(encoding))throw Error('INVALID_PROOF_ENCODING');
const approvalMode=process.env.APPROVAL_MODE??'require-finality';if(!['require-finality','signed-envelope'].includes(approvalMode))throw Error('INVALID_APPROVAL_MODE');
const proofBudgetMs=Number(process.env.PROOF_BUDGET_MS??45000);if(!Number.isInteger(proofBudgetMs)||proofBudgetMs<1||proofBudgetMs>50000)throw Error('INVALID_PROOF_BUDGET');
const server=createAgent({secret:process.env.AGENT_GAMES_HMAC_SECRET??'',replayDir:process.env.REPLAY_DIR??'data/replay',encoding:encoding as 'disabled'|'sha256-field-v1',approvalMode:approvalMode as 'require-finality'|'signed-envelope',proofWorkers:Number(process.env.PROOF_WORKERS??2),proofBudgetMs});
server.listen(Number(process.env.PORT??3000),'0.0.0.0',()=>console.log('DAYFALL-AGENT listening; encoding='+encoding+'; approval='+approvalMode));

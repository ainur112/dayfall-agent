import {createHash,randomBytes} from 'node:crypto';
import {check} from './policy.js';
export const FIELD=21888242871839275222246405745257275088548364400416034343698204186575808495617n;
/** Experimental adapter: independently tested locally, NOT confirmed by platform practice. */
export function encode(task:any,decision:'APPROVE'|'REJECT'):Record<string,string>{
 if(check(task.input)==='INVALID_INPUT'||typeof task.task_id!=='string')throw Error('INVALID_INPUT');
 const i=task.input,field=(v:string)=> (BigInt(v)%FIELD).toString();
 if(i.registered_vk.toLowerCase()!==i.proof_vk.toLowerCase()&&field(i.registered_vk)===field(i.proof_vk))throw Error('VK_FIELD_ALIAS');
 return {taskId:field('0x'+createHash('sha256').update(task.task_id,'utf8').digest('hex')),registeredVkHash:field(i.registered_vk),proofVkHash:field(i.proof_vk),minimum:i.minimum,publicBalance:i.public_balance,expiryBlock:String(i.expiry_block),currentBlock:String(i.current_block),recipient:BigInt(i.recipient).toString(),conditionRecipient:BigInt(i.condition_recipient).toString(),amount:i.amount,maxTransfer:i.max_transfer,decision:decision==='APPROVE'?'1':'0',salt:field('0x'+randomBytes(32).toString('hex'))};
}
export function expectedSignals(w:Record<string,string>):string[]{return ['registeredVkHash','proofVkHash','minimum','publicBalance','expiryBlock','currentBlock','recipient','conditionRecipient','amount','maxTransfer','decision','taskId'].map(k=>w[k]);}

// Public HTTP entry; implementation is split for transport/proof isolation.
export {createAgent} from './handler.js';
